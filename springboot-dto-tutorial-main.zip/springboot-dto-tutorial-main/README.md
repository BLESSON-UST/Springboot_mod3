# springboot-dto-tutorial
Spring Boot DTO Example Tutorial | Data Transfer Object Pattern at https://youtu.be/THv-TI1ZNMk

Spring Boot DTO Tutorial - Entity to DTO Conversion using ModelMapper Library | In 4 Simple Steps at https://youtu.be/ZY4mUro6Kd0




