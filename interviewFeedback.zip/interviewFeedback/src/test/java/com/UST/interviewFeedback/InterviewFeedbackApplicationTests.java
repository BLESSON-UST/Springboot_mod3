package com.UST.interviewFeedback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterviewFeedbackApplicationTests {

	@Test
	void contextLoads() {
	}

}
