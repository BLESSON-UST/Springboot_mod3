package com.UST.interviewSchedule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterviewScheduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
