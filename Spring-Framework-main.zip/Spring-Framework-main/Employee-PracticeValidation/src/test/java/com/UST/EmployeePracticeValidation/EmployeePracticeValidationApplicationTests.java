package com.UST.EmployeePracticeValidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeePracticeValidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
