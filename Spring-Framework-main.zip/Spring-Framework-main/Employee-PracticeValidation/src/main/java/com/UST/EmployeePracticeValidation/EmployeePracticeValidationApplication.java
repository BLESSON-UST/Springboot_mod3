package com.UST.EmployeePracticeValidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeePracticeValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeePracticeValidationApplication.class, args);
	}

}
