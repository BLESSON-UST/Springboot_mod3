package com.UST.EmployeePracticeValidation.exception;

public class IdNotFoundException extends RuntimeException{
    public IdNotFoundException(String msg) {
        super(msg);
    }
}
