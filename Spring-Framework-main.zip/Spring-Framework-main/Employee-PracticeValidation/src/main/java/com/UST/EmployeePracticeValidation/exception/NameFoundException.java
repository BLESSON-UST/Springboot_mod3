package com.UST.EmployeePracticeValidation.exception;

public class NameFoundException extends RuntimeException{
    public NameFoundException(String msg) {
        super(msg);
    }
}