package com.UST.EmployeePracticeException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeePracticeExceptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
