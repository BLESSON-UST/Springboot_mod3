package com.UST.EmployeePracticeException.exception;

public class NameFoundException extends RuntimeException{
    public NameFoundException(String msg) {
        super(msg);
    }
}
