package com.UST.EmployeePracticeCrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeePracticeCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeePracticeCrudApplication.class, args);
	}

}
